#include <iostream>
using namespace std;

class tic1
{
public:
	void play1();
	int checkwin();
	void board();
};

#include <iostream>
using namespace std;

class parity {
private:
    int* array;
public:
    parity(int num1) {
        array = new int[num1]; 
    }
    void cheak(int num2);
  ~parity() {
    cout << "destructor called" << endl;
  }
    
};

void parity::cheak(int num2) {

    if (num2 / 2 == 0)
        cout << "true";
    else 
        cout << "false";
}

int main() {
    int n;
    cout << "enter number of items" << endl;
    cin >> n;
    parity s2(n);
    s2.cheak(n);
    return 0;

}
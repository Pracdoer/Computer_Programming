#include <iostream>
using namespace std;

class integers {

    private:
        unsigned int count[32];

    public:
        integers() {
            cout << "cunstructor has been called " << endl;
            for(int i = 0; i < 32; i++)
                count[i] = 0;
        }
        integers(int num){
            cout << "constructer 2 has been called" << endl;
            for(int i = 0; i < 32; i++)
                count[i] = num;    
        }
        void set(int index , int var);
        void clear(int index);
        void test(int test);
        ~integers() {
            cout << "destructor called " << endl;
        }
};
void integers::set(int index, int var) {

    if (index > 32 or index < 0)
        cout << "invaild input";
    else 
        count[index] = var;
}
void integers::clear(int index) {

    if (index > 32 or index < 0)
        cout << "invaild input";
    else 
        count[index] = 0;
}
void integers::test(int var) {
    int temp= 0;
    for (int i = 0; i < 32; i++) {
        if (count[i] == var) {
            cout << "element is present " << endl;
            break;
        }
        else 
            temp = 1;    
    }  
    if (temp == 1)
        cout << "element is not present " << endl;    
}

int main() {

    integers s1;
    s1.set(3, 5);
    s1.clear(3);
    s1.test(2);
    return 0;
}
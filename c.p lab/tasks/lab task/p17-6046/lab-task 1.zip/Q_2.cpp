#include <iostream>
using namespace std;

int isPrime(int num) {

	  int isprime = 1;

      for(int i = 2; i <= num / 2; i++)  {
           if(num % i == 0)  {
                isprime = 0;
                break;
           }
      }
      if (isprime == 1)
           cout << "given number is Prime " << endl;
      
      else
          cout << "given number is not Prime " << endl; 
return 0;
  
}


int main() {

   int prime = 1;
   int n;
   cout << "enter a number to cheak prime " << endl;
   cin >> n;
   isPrime(n);

   cout << "list of all prime numbers upt0 100 " <<endl;
   for (int i = 3; i < 100 ; i++) {
      prime  = 1;
     for(int j = 2; j < i; j++)  {
       if(i % j == 0)  {
          prime = 0;
          break;
      }
    }
    if (prime == 1) 
      cout << i << "  ";
   }

return 0;
}

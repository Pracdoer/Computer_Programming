#include <iostream>
using namespace std;

//Q_1(4) --> function checks wether a number is pallindrome or not.

int pallindrome(int num) {

    int n = num;
    int reverse;
    int rem;

    while (num != 0) {
           
          rem = num % 10;
          reverse = (reverse * 10) + rem;
          num /= 10; 
   }

   if (n == reverse)
   	cout << "the given number is a pallindrome" <<endl;

   else 
       cout << " the given number is not a pallindrome " << endl;

return 0;
}

int integerNumberLength(int num) { 
    int  count = 0;
    
    while(num) {
    
    	num /= 10;
    	count++;
    }
    return count;
}

//Q_1(5) --> displays on console which number has highest length. Use integerNumberLength() function

void largestNumberLength(int num1, int num2, int num3, int num4) {

    int num;
	int count;
	int count1 = 0;
   
    for (int i = 0; i < 4; i++) {
    	if ( i == 0) {
        	count = integerNumberLength(num1);
       		if (count > count1) {
       			count1  = count;
       			num = num1;
       		}
       	}
       	if ( i == 1) {
        	count = integerNumberLength(num2);
       		if (count > count1) {
       			count1  = count;
       			num = num2;
       		}
       	} 
       	if ( i == 2) {
        	count = integerNumberLength(num3);
       		if (count > count1) {
       			count1  = count;
       			num = num3;
       		}
       	}
       	if ( i == 3) {
        	count = integerNumberLength(num4);
       		if (count > count1) {
       			count1  = count;
       			num = num4;
       		}
       	}
	}
       cout << num << " has the highest length = " << count1 <<endl;
}


int main() {

	int numb;
 	cout << "enter the number to cheak pallindrome " << endl;
    cin >> numb;
    pallindrome(numb);

	
	int a , b, c, d;
	cout << "enter the number " <<endl;
	cin >> a;
	cout << "enter the number " <<endl;
	cin >> b;
	cout << "enter the number " <<endl;
	cin >> c;
    cout << "enter the number " <<endl;
	cin >> d;
	largestNumberLength(a,b,c,d);

return 0;
}

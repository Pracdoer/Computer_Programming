#include <iostream>
#include <string>
using namespace std;



//Q_1 (1) int maximum(int num1, int num2, int num3, int num4, int num5).

int maximum(int num1, int num2, int num3, int num4, int num5) {
   
    if(num1 > num2 && num1 > num3 && num1 > num4 && num1 > num5) 
         cout << "max number is " << num1 <<endl; 

    if(num2 > num1 && num2 > num3 && num2 > num4 && num1 > num5) 
         cout << "max number is " << num2 <<endl;
     
    if(num3 > num1 && num3 > num2 && num3 > num4 && num3 > num5) 
         cout << "max number is " << num3 <<endl;
      
    if(num4 > num1 && num4 > num2 && num4 > num3 && num4 > num5) 
         cout << "max number is " << num4 <<endl;
	 
    else
        cout << "max number is " << num5 << endl;
    
         
  return 0;
}  

//Q_1(2) --> functions calculates the length of variable num and returns it’s length.

int integerNumberLength(int num) { 
    int  count = 0;
    
    while(num) {
    
    	num /= 10;
    	count++;
    }
    cout << "The length og given number is " << count << endl; 
    
  return 0;
}
 
//Q_1(3) --> function converts a uppercase letter to lowercase and returns an lowercase letter.

char lowerLetter(char ch) {
    
    if (isupper(ch))
          ch = (tolower(ch));

    cout <<  "the converted char is " << ch <<endl;

return 0;
} 



int main() {

	int num1, num2, num3, num4, num5;
	cout << "enter a number :" << endl;
	cin >> num1;
	
	cout << "enter a number :" << endl;
	cin >> num2;
	cout << "enter a number :" << endl;
	cin >> num3;
	cout << "enter a number :" << endl;
	cin >> num4;
	cout << "enter a number :" << endl;
	cin >> num5;
	maximum(num1, num2, num3, num4, num5);
	
	int number;
	cout << "enter a number to find its length: " << endl;
	cin >> number;
	integerNumberLength(number);

    char cha;
    cout << "enter a char " << endl;
    cin >> cha;
    lowerLetter(cha);

	
return 0;
}

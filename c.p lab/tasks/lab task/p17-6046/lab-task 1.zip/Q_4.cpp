#include <iostream>
using namespace std;

long Pentagonal(int num) {

	long result;
	cout << endl;
	for (int i = 1; i <= num; i++) {
		
		result = (i * ((3 * i) -1)) / 2;
		cout << result <<',';
		
	} 

return 0;
}


int main() {

	long n ;
	cout << "Enter the number n to form the sequence " << endl;
	cin >> n;
	Pentagonal(n);
 
return 0;
}

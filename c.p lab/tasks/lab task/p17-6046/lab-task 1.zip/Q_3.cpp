#include <iostream>
using namespace std;


void reverse(int num) {

    int rev;
    int rem;

    while (num) {
           
          rem = num % 10;
          rev = (rev * 10) + rem;
          num /= 10; 
   }
   cout << "The reverse number is " << rev << endl;
}

int main() {

	int n;
	cout << "enter a number to reverse it " << endl;
	cin >> n;
	reverse(n);

    	
    int revs;
    int remm;
    int array[10];
    int num1;
    int num;
    
    cout << "enter a numbers to reverse it " << endl;
    
	for (int i = 0; i < 10; i++) { 
		cin >> num1;
		array[i] = num1;
    }
    cout << "the list of 10 reverse number " << endl;
    
	for (int i = 0; i < 10; i++) {
        num = array[i];
        while (num != 0) {
            remm = num % 10;
            revs = (revs * 10) + remm;
            num /= 10; 
        }
        cout << revs << endl;
   }
   

return 0;
}

		

#include <iostream>
#include <stdlib.h>
using namespace std;


long fib(int n) {
	
	long value = 0;   
	long p_value = 1; 
	long n_value = 0; 
    if (n < 2)
        cout << n;
        
    else {
         for(int i = 0; i < n; i += 1)   {
             n_value = value + p_value;          
             value = p_value;                  
             p_value = n_value; 
             cout << value << ',';               
         }   
    }
    
return 0;                         
}

int main() {

	long n;
    cout << "Enter a number for fib series " << endl;
    cin >> n;
    fib(n);
    
    return 0;
}

#include <iostream>
using namespace std;


void rotate(int& a, int& b, int& c, int& d, int& e) {

	int temp1 = b;
	int temp2 = c;
	int temp3 = d;
	int temp4 = e;
	int temp5 = a;
	
	a = temp1;
	b = temp2;
	c = temp3;
	d = temp4;
	e = temp5;

}



int main() {

	int num1, num2,num3,num4, num5;
	cout << "enter the number " << endl;
	cin >> num1;
	cout << "enter the number " << endl;
	cin >> num2;
	cout << "enter the number " << endl;
	cin >> num3;
	cout << "enter the number " << endl;
	cin >> num4;
	cout << "enter the number " << endl;
	cin >> num5;
	
	cout << "before rotating " << endl;
	cout <<"a = " << num1 << ' ' <<"b = " <<num2 <<' ' <<"c = " << num3 <<' ' <<"d = " << num4 << ' ' <<"e = " << num5 << ' ' <<endl;

	rotate(num1,num2,num3,num4,num5);
	cout << "after rotating " << endl;
	
	cout <<"a = " << num1 << ' ' <<"b = " <<num2 <<' ' <<"c = " << num3 <<' ' <<"d = " << num4 << ' ' <<"e = " << num5 << ' ' <<endl; 

return 0; 
}
